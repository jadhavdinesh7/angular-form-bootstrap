import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
 
  title = 'mybootstrapform';

  firstName:string = "";
  lastName:string = "";
  age:string = "";
  dept:string = "";
  day:string = "";
  month:string = "";
  year:string = "";
  
  constructor(){

  }

  ngOnInit(): void {
  }

  formDetails = {firstName:"", lastName: "", age: "", dept: "", dob: new Date()};

  showFormDetails(){
    this.formDetails.firstName = this.firstName;
    this.formDetails.lastName = this.lastName;
    this.formDetails.age = this.age;
    this.formDetails.dept = this.dept;
    this.formDetails.dob = new Date(this.month + "-" + this.day + "-" + this.year);
  }
}
